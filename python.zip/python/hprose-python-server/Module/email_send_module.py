#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
sys.path.append("../..")
import threading
import Common.authenticate,Library.email_process_class

# 发送邮件模块
def mailHandle(to,subject,content,domain,time_stamp,hash_info,block_state=1):
    # 身份验证
    if Common.authenticate.auth(time_stamp, hash_info):
        # 实例化发送邮件类
        oop = Library.email_process_class.emailProcess(to, subject, content, domain)
        # 阻塞方式发邮件
        if block_state:
            state = oop.sendEmail()
            if (state):
                return 1
            else:
                return 0
        # 非阻塞方式发邮件
        else:
            try:
                thread = threading.Thread(target=oop.sendEmail, args=())
                # 不等待线程执行完毕
                thread.setDaemon(False)
                thread.start()
                # 等待子线程执行完毕
                # thread.join()
                return 1
            except Exception:
                return 0
    # 身份验证失败
    else:
        return 0



