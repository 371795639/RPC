# !/usr/bin/python
# -*- coding: UTF-8 -*-
class rpcConfig:

        # RPC调用配置信息
        API_KEY = "EjpNVSNQTyGi1VvWECj9TvC/+kq3oteste2kTfQUs8yCM6xX9Yjq52v54g+HVoknA"
        #邮件发送配置信息-qeebey
        MAIL_HOST_DEFAULT = "smtp.exmail.qq.com"  # 设置服务器
        MAIL_USER_DEFAULT = "test@exmail.com"    # 用户名
        MAIL_PASS_DEFAULT = "testpassword"         # 口令

