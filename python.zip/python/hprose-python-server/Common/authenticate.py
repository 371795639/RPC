# !/usr/bin/python
# -*- coding: UTF-8 -*-
import sys,hashlib
sys.path.append('../..')
import Conf.config

def auth(time_stamp,hash_info):
    str = Conf.config.rpcConfig.API_KEY + time_stamp
    # 创建md5对象
    hl = hashlib.md5()
    hl.update(str.encode(encoding='utf-8'))
    res_hash = hl.hexdigest()
    if res_hash == hash_info:
        return 1
    else:
        return 0