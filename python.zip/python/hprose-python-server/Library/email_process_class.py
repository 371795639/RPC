#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
sys.path.append("../..")
import smtplib
import Conf.config
from email.mime.text import MIMEText
from email.header import Header
from email.utils import parseaddr, formataddr

class emailProcess():

    # 邮箱配置信息
    sender_param = ["your.server", "send@email.com", "test"]
    # sender_param = ["smtp.exmail.qq.com", "sales@qeebey.com", "Grow@699757"]

    # 初始化
    def __init__(self, to, subject, content, domain):  # 第一个参数必须是self
        self.to = to
        self.subject = subject
        self.content = content
        self.domain = domain

    # 格式化邮件地址
    def formatAddr(self,s):
        name, addr = parseaddr(s)
        return formataddr((Header(name, 'utf-8').encode(), addr))

    # 调用邮件发送
    def sendEmail(self):
            # 通过domain进行动态获取mail_host mail_user mail_pass
            # dom = self.domainMail(self.domain)
            mail_host = self.sender_param[0]  # 设置服务器
            mail_user = self.sender_param[1]  # 用户名
            mail_pass = self.sender_param[2]  # 口令

            sender = mail_user  # 发送者邮箱
            receivers = [self.to]  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱

            message = MIMEText(self.content, 'html', 'utf-8')
            subject = self.subject

            # Header对中文进行转码
            message['From'] = self.formatAddr('管理员 <%s>' % sender).encode()
            message['To'] = ','.join(receivers)
            message['Subject'] = Header(subject, 'utf-8')

            try:
                smtpObj = smtplib.SMTP_SSL(mail_host, 465)
                #smtpObj.connect(mail_host, 25)  # 25 为 SMTP 端口号
                smtpObj.login(mail_user, mail_pass)
                smtpObj.sendmail(sender, receivers, message.as_string())
                # print("邮件发送成功")
                return 1
            except smtplib.SMTPException as e:
                print("Error: 无法发送邮件")
                print 'str(Exception):\t', str(Exception)
                print 'str(e):\t\t', str(e)
                print 'repr(e):\t', repr(e)
                print 'e.message:\t', e.message
                return 0


    # 根据domain获取对应服务器 用户名 口令
    # def domainMail(self,d):
    #
    #     if d == "ipasspay.biz":
    #         info = [Conf.config.rpcConfig.MAIL_HOST_IPASSPAY,
    #                 Conf.config.rpcConfig.MAIL_USER_IPASSPAY,
    #                 Conf.config.rpcConfig.MAIL_PASS_IPASSPAY]
    #
    #     elif d == "ipasswallet.biz":
    #         info = [Conf.config.rpcConfig.MAIL_HOST_IPASSWALLET,
    #                 Conf.config.rpcConfig.MAIL_USER_IPASSWALLET,
    #                 Conf.config.rpcConfig.MAIL_PASS_IPASSWALLET]
    #     else:
    #         info = [Conf.config.rpcConfig.MAIL_HOST_DEFAULT,
    #                 Conf.config.rpcConfig.MAIL_USER_DEFAULT,
    #                 Conf.config.rpcConfig.MAIL_PASS_DEFAULT]
    #
    #     return info


